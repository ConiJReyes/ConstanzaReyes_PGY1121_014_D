#libreria/biblioteca examen transversal
#importar
import datetime
#asientos,precios y ganancias
asientos = [""] * 101
precios = {"Platinum": 120000, "Gold": 80000, "Silver": 50000}
ganancias = {"Platinum": 0, "Gold": 0, "Silver": 0}
#compra de entradas
def comprar_entradas():
    cantidad = int(input("Ingrese la cantidad de entradas que quiere comprar (1-3): "))
    while cantidad < 1 or cantidad > 3:
        print("Cantidad invalida. Intentelo nuevamente.")
        cantidad = int(input("Ingrese la cantidad de entradas que quiere comprar (1-3): "))
#asientos
    print("Ubicaciones disponibles:")
    print("Asiento\tEstado")
    for i in range(1, len(asientos)):
        if asientos[i] == "":
            print(f"{i}\t\tDisponible")
        else:
            print(f"{i}\t\tVendido")

    for _ in range(cantidad):
        asiento = int(input("Seleccione una ubicación: "))
        while asientos[asiento] != "":
            print("Ubicación no disponible. Intente nuevamente.")
            asiento = int(input("Seleccione una ubicación: "))

        asientos[asiento] = input("Ingrese el RUN del asistente (sin guiones, puntos ni digito verificador): ")
        tipo_entrada = determinar_tipo_entrada(asiento)
        ganancias[tipo_entrada] += precios[tipo_entrada]

    print("Operacion exitosa.")

#tipo de entrada,golden,platinum o silver
def determinar_tipo_entrada(asiento):
    if asiento <= 20:
        return "Platinum"
    elif asiento <= 50:
        return "Gold"
    else:
        return "Silver"

#disponibilidad de ubicaciones
def mostrar_ubicaciones_disponibles():
    print("Ubicaciones disponibles:")
    print("Asiento\tEstado")
    for i in range(1, len(asientos)):
        if asientos[i] == "":
            print(f"{i}\t\tDisponible")
        else:
            print(f"{i}\t\tVendido")

#personas que van a ir al evento
def ver_listado_asistentes():
    asistentes = [asientos[i] for i in range(1, len(asientos)) if asientos[i] != ""]
    asistentes.sort()
    print("Listado de asistentes:")
    for asistente in asistentes:
        print(asistente)

#ganancias totales del evento
def mostrar_ganancias_totales():
    print("Ganancias totales:")
    print("Tipo Entrada\tCantidad\tTotal")
    total = 0
    for tipo, ganancia in ganancias.items():
        cantidad = ganancia // precios[tipo]
        total += ganancia
        print(f"{tipo}\t\t{cantidad}\t\t${ganancia}")

    print(f"TOTAL\t\t\t\t\t${total}")
