#menu principal examen transversal
import datetime
import biblioteca
#definir menu creativos.cl
def mostrar_menu():
    print("""=====Menu=====
    1- Comprar entradas
    2- Mostrar ubicaciones disponibles
    3- Ver listado de asistentes
    4- Mostrar ganancias totales
    5- Salir""")
#conexion con la biblioteca
def main():
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opcion entre 1-5: ")

        if opcion == "1":
            biblioteca.comprar_entradas()
        elif opcion == "2":
            biblioteca.mostrar_ubicaciones_disponibles()
        elif opcion == "3":
            biblioteca.ver_listado_asistentes()
        elif opcion == "4":
            biblioteca.mostrar_ganancias_totales()
        elif opcion == "5":
            fecha_actual = datetime.datetime.now().strftime("%d-%m-%Y")
            print(f"-Gracias por utilizar el programa- Salida del sistema - {fecha_actual}")
            break
        else:
            print("Opción invalida, por favor intentelo nuevamente con una de las opciones disponibles.")
#verif
if __name__ == "__main__":
    main()
